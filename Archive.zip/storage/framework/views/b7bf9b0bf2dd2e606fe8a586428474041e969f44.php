<?php $__env->startSection('title'); ?> <?php echo e(env("APP_NAME")); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-xl-8 ">
                <div class="row justify-content-between align-items-center">
                        <div class="col-12 col-lg-4 mb-4 mb-lg-0">
                                <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" class="w-100 rounded-2" alt="">
                        </div>
                        <div class="col-12 col-lg-8">
                            <h4 class="mb-2 mb-lg-0 fw-bold"><?php echo e($post->title); ?></h4>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex">
                                    <img src="<?php echo e(asset($post->user->photo)); ?>" class="mt-1 user-img rounded-circle border-white shadow" alt="">
                                    <p class="mb-0 ms-2">
                                        <?php echo e($post->user->name); ?> <br>
                                        <i class="fas fa-calendar text-primary"></i> <?php echo e($post->created_at->format("d-M-Y")); ?>

                                    </p>
                                </div>
                                <a href="<?php echo e(route('index')); ?>" class="btn btn-outline-primary">Read All</a>
                            </div>
                            <hr>
                            <p>
                                <?php echo e($post->description); ?>

                            </p>
                        </div>
                </div>
                <div class="text-end">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>
                    <a href="<?php echo e(route('post.edit',$post->id)); ?>" class="btn btn-sm btn-outline-warning">
                        <i class="fas fa-edit"></i>
                    </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$post)): ?>
                    <form class="d-inline-block" action="<?php echo e(route('post.destroy',$post->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </form>
                        <?php endif; ?>
                </div>
                <?php if($post->galleries->count()): ?>
                    <div class="row border rounded p-4 g-4 mt-2 mb-4 d-flex justify-content-center">
                        <?php $__currentLoopData = $post->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6 col-lg-4 col-xl-3">
                            <a class="venobox" data-gall="gallery" href="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>">
                                <img src="<?php echo e(asset('storage/gallery/'.$gallery->photo)); ?>" class="gallery-photo rounded" alt="">
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <div class="row justify-content-center align-items-center mb-5">
                    <div class="col-12 col-lg-8">
                        <div class="text-center mb-3">
                            <h4>Users' Comments</h4>
                        </div>
                        <div class="comments">
                            <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="border p-3 rounded-3 mb-3" id="comment">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small class="d-flex">
                                        <img src="<?php echo e(asset($comment->user->photo)); ?>" class="mt-1 user-img rounded-circle border-white shadow" alt="">
                                        <p class="mb-0 ms-2">
                                            <?php echo e($comment->user->name); ?> <br>
                                            <i class="fas fa-calendar text-primary"></i> <?php echo e($comment->created_at->diffforhumans()); ?>

                                        </p>
                                    </small>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$comment)): ?>
                                    <form action="<?php echo e(route('comment.destroy',$comment->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-sm btn-outline-danger rounded-circle">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                                <p class="ps-5 mb-0"><?php echo e($comment->message); ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-center">
                                    There is no comment Yet!
                                    <?php if(auth()->guard()->check()): ?>
                                        Start comment now
                                    <?php endif; ?>
                                    <?php if(auth()->guard()->guest()): ?>
                                        <a href="<?php echo e(route('login')); ?>">Login</a>to comment.
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                        <div class="">
                            <form action="<?php echo e(route('comment.store')); ?>" method="post" id="commentForm">
                                <?php echo csrf_field(); ?>
                                <div class="form-floating mb-3">
                                    <input type="hidden" value="<?php echo e($post->id); ?>" name="post_id">
                                    <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-3" name="message" placeholder="Leave a comment here" style="height: 100px" id="floatingTextarea"></textarea>
                                    <label for="floatingTextarea">Comments</label>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger ps-2"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="text-center">
                                    <button class="btn btn-primary">Comment</button>
                                </div>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div class="bg-primary text-light d-flex justify-content-center align-items-center index-footer">
        <p class="mb-0">
            &copy; <?php echo e(date('Y')); ?> United Wood Industries. All Right Reversed.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        new VenoBox({
            selector: '.venobox'
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel_online\The-Explorer-Laravel-online\resources\views/post/detail.blade.php ENDPATH**/ ?>