<?php $__env->startSection('title'); ?> <?php echo e(env("APP_NAME")); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 col-xl-8 ">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="border rounded-3 d-flex justify-content-between align-items-center p-4 mb-4">
                            <h4 class="mb-0">
                                <span class="text-black-50 fw-bold">Welcome</span>
                                <br>
                                <span class="fw-bold"><?php echo e(auth()->user()->name); ?></span>
                            </h4>
                            <a href="<?php echo e(route('post.create')); ?>" class="btn btn-lg btn-primary">Create Post</a>
                        </div>
                    <?php endif; ?>
                        <div class="d-flex justify-content-end align-items-center mb-4">
                            <?php echo e($posts->links()); ?>

                        </div>
                        <div class="posts">
                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="post mb-4">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <img src="<?php echo e(asset('storage/cover/'.$post->cover)); ?>" class="cover-img w-100 rounded-3" alt="">
                                    </div>
                                    <div class="col-lg-8">
                                        <div class="d-flex flex-column justify-content-between h-350 py-4">
                                            <div>
                                                <h4 class="fw-bold"><?php echo e($post->title); ?></h4>
                                                <p class="text-black-50 mb-0">
                                                    <?php echo e($post->excerpt); ?>

                                                </p>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="d-flex">
                                                    <img src="<?php echo e(asset($post->user->photo)); ?>" class="mt-1 user-img rounded-circle border-white shadow" alt="">
                                                    <p class="mb-0 ms-2">
                                                        <?php echo e($post->user->name); ?> <br>
                                                        <i class="fas fa-calendar"></i> <?php echo e($post->created_at->format("d-M-Y")); ?>

                                                    </p>
                                                </div>
                                                <a href="<?php echo e(route('detail',$post->slug)); ?>" class="btn btn-outline-primary">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div class="bg-primary text-light d-flex justify-content-center align-items-center index-footer">
        <p class="mb-0">
            &copy; <?php echo e(date('Y')); ?> United Wood Industries. All Right Reversed.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel_online\The-Explorer-Laravel-online\resources\views/index.blade.php ENDPATH**/ ?>