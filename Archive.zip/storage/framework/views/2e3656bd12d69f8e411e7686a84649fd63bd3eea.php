<?php $__env->startSection('title'); ?> Edit Profile <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-xl-5 ">
                    <div class="text-center">
                        <img src="<?php echo e(asset(auth()->user()->photo)); ?>" class="profile-img" alt="" id="photoUi">
                        <br>
                        <button class="btn btn-sm btn-primary" id="editPhoto" style="margin-top: -35px">
                            <i class="fas fa-pencil-alt"></i>
                        </button>
                        <p class="mb-0"><?php echo e(auth()->user()->name); ?></p>
                        <p class="small text-black-50"><?php echo e(auth()->user()->email); ?></p>
                    </div>
                    <form action="<?php echo e(route('profile.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" class="d-none" name="photo" accept="image/jpeg,image/png" id="photoUpload">
                        <div class="form-floating mb-3">
                            <input type="text" name="name" value="<?php echo e(old('name',auth()->user()->name)); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="userName" placeholder="no need">
                            <label for="userName">User Name</label>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger ps-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" disabled name="email" value="<?php echo e(auth()->user()->email); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="userEmail" placeholder="no need">
                            <label for="userEmail">Email</label>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger ps-2"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="text-center">
                            <button class="bn btn-primary btn-lg rounded-3">
                                <i class="fas fa-upload"></i>
                                Update
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div class="bg-primary text-light d-flex justify-content-center align-items-center edit-profile-footer">
        <p class="mb-0">
            &copy; <?php echo e(date('Y')); ?> United Wood Industries. All Right Reversed.
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        let photoUi = document.getElementById('photoUi')
        let photoUpload = document.getElementById('photoUpload');
        let editPhoto = document.getElementById('editPhoto');

        editPhoto.addEventListener('click', () => photoUpload.click());
        photoUpload.addEventListener('change',() => {
            const reader = new FileReader();
            const file = photoUpload.files[0];
            reader.onload = function (){
                photoUi.src = reader.result;
            }
            reader.readAsDataURL(file);
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\Laravel_online\The-Explorer-Laravel-online\resources\views/profile/edit-profile.blade.php ENDPATH**/ ?>