<?php echo e($slot); ?>

<?php /**PATH C:\Users\user\Desktop\Laravel_online\The-Explorer-Laravel-online\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>